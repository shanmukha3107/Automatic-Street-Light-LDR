# Automatic Street Light Using LDR and Microcontroller

## Project Overview

This project demonstrates an **Automatic Street Light System using an LDR (Light Dependent Resistor) and an Arduino microcontroller**.

The LDR senses the surrounding light intensity. The Arduino reads the sensor value and compares it with a selected threshold. When the environment becomes dark, the LED street light is switched ON. When sufficient light is available, the LED is switched OFF.

The project is designed as an embedded-system application that demonstrates sensor interfacing, analog input processing, conditional control, and automatic output control.

## Objectives

- Understand the basics of embedded systems and microcontrollers.
- Interface an LDR sensor with an Arduino.
- Measure ambient light intensity using an analog input.
- Control an LED automatically according to light conditions.
- Learn threshold-based decision making.
- Test and troubleshoot a sensor-based embedded circuit.

## Components Required

| Component | Quantity |
|---|---:|
| Arduino Uno | 1 |
| LDR | 1 |
| 10 kΩ resistor | 1 |
| LED | 1 |
| 220 Ω resistor | 1 |
| Breadboard | 1 |
| Jumper wires | As required |
| USB cable | 1 |

## Working Principle

The LDR changes its resistance according to the amount of light falling on it. It is connected with a resistor as a voltage divider, and the junction is connected to the Arduino analog input A0.

The Arduino continuously reads the LDR value:

1. Light intensity is detected by the LDR.
2. The LDR voltage-divider produces an analog voltage.
3. Arduino reads the analog value through A0.
4. The reading is compared with `DARK_THRESHOLD`.
5. If the reading indicates darkness, the LED is switched ON.
6. If the reading indicates sufficient brightness, the LED is switched OFF.

## Circuit Connections

### LDR voltage divider

- LDR one terminal → Arduino 5V
- LDR other terminal → Arduino A0
- 10 kΩ resistor → between A0 and GND

### LED

- Arduino D9 → 220 Ω resistor → LED anode
- LED cathode → GND

See `docs/street_light_block_diagram.png` for the project block diagram.

## Software

The program is written in the Arduino IDE using C/C++.

### Upload Procedure

1. Install Arduino IDE.
2. Connect the Arduino Uno to the computer using USB.
3. Open `src/Automatic_Street_Light_LDR.ino`.
4. Select the correct Arduino board and COM port.
5. Upload the program.
6. Open Serial Monitor at 9600 baud.
7. Observe the LDR readings.
8. Adjust `DARK_THRESHOLD` if required for the actual lighting conditions.

## Testing

The system can be tested under different lighting conditions:

| Test Condition | Expected Result |
|---|---|
| Bright light | LED OFF |
| Reduced light | LED response changes according to threshold |
| Darkness | LED ON |
| Repeated light/dark changes | Automatic switching |

The threshold may need calibration because actual LDR readings depend on the sensor, resistor value, wiring, and surrounding lighting.

## Challenges and Hurdles

- LDR readings can vary under different lighting conditions.
- Selecting a suitable threshold is important for reliable switching.
- Circuit wiring and program conditions need to be checked during troubleshooting.
- LED switching near the threshold may require repeated testing and adjustment.

## Lessons Learned

- Practical interfacing of an LDR with a microcontroller.
- Reading analog sensor values.
- Using conditional statements for automatic control.
- Selecting and refining a sensor threshold.
- Systematic hardware and software troubleshooting.
- Testing an embedded system under different operating conditions.

## Future Scope

The basic project can be extended with:

- Multiple street lights.
- PWM-based brightness control.
- Motion/PIR sensing for additional energy saving.
- Solar-powered operation.
- IoT monitoring and remote control.
- Fault detection and status reporting.
- More advanced light-intensity calibration.

## Repository Structure

```text
Automatic-Street-Light-LDR/
├── README.md
├── LICENSE
├── .gitignore
├── src/
│   └── Automatic_Street_Light_LDR.ino
├── docs/
│   ├── PROJECT_REPORT.md
│   └── street_light_block_diagram.png
└── report/
    └── Jada_Shanmukha_Srinivas_Automatic_Street_Light_Report.docx
```

## Author

**Jada Shanmukha Srinivas**  
**Domain:** Embedded and IoT

## Project Title

**Automatic Street Light Using LDR and Microcontroller**
