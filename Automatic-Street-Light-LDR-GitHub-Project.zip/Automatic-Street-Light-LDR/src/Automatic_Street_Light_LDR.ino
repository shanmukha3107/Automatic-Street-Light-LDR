/*
  Automatic Street Light Using LDR and Arduino
  Project: Embedded and IoT

  Description:
  The LDR senses ambient light. The Arduino reads the LDR value and
  automatically switches the street-light LED ON in darkness and OFF
  in bright light.

  Hardware:
  - Arduino Uno
  - LDR
  - 10k ohm resistor
  - LED
  - 220 ohm resistor
  - Breadboard and jumper wires

  Connections:
  LDR voltage divider:
    LDR junction -> A0
    LDR one side -> 5V
    10k resistor one side -> GND
    10k resistor other side -> A0

  LED:
    Arduino D9 -> 220 ohm resistor -> LED anode
    LED cathode -> GND

  Note:
  The threshold value may need adjustment depending on the LDR,
  resistor, and surrounding light conditions.
*/

const int LDR_PIN = A0;
const int LED_PIN = 9;

// Adjust this value after observing the Serial Monitor.
// With the voltage-divider arrangement above, lower readings generally
// correspond to darker conditions.
const int DARK_THRESHOLD = 500;

void setup() {
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  Serial.begin(9600);
}

void loop() {
  int ldrValue = analogRead(LDR_PIN);

  Serial.print("LDR Value: ");
  Serial.println(ldrValue);

  if (ldrValue < DARK_THRESHOLD) {
    // Dark condition: street light ON
    digitalWrite(LED_PIN, HIGH);
  } else {
    // Bright condition: street light OFF
    digitalWrite(LED_PIN, LOW);
  }

  delay(500);
}
