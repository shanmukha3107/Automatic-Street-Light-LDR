# Automatic Street Light Using LDR and Microcontroller

## 1. Preface

This project provided practical experience in embedded systems and microcontroller-based sensor interfacing. The work focused on developing an automatic street light system using an LDR sensor and a microcontroller.

The project helped in understanding how a sensor input can be processed by a microcontroller and used to control an output automatically. The work included circuit development, Arduino programming, threshold selection, testing under different lighting conditions, troubleshooting, and documentation.

## 2. Introduction

An automatic street light system is an embedded application in which lighting is controlled according to surrounding light conditions. In this project, an LDR is used to sense ambient light and an Arduino microcontroller processes the sensor reading.

The system is intended to demonstrate automatic switching without requiring manual operation.

### 2.1 Objective

- Interface an LDR with a microcontroller.
- Read ambient light intensity.
- Control an LED according to a threshold.
- Develop practical Arduino programming skills.
- Test and troubleshoot the complete system.

## 3. Problem Statement

Manual operation of lights can result in lights remaining ON when they are not required. The project addresses this by using an LDR-based sensing system that automatically controls the light according to ambient brightness.

## 4. Existing and Proposed Solution

### Existing Approach

A conventional light may be controlled manually, requiring a person to switch it ON or OFF.

### Proposed Solution

The proposed system uses an LDR sensor and Arduino. The LDR detects ambient light, Arduino reads the sensor value, and the LED is automatically switched according to a predefined threshold.

## 5. Proposed Design / Model

### System Flow

```text
Ambient Light
     ↓
    LDR
     ↓
Voltage Divider
     ↓
Arduino Analog Input
     ↓
Threshold Comparison
     ↓
LED Control
     ↓
Street Light Output
```

### Main Interfaces

- LDR → Arduino A0
- LED → Arduino D9
- Arduino USB → Computer for programming and monitoring

## 6. Performance Test

The project was tested under different lighting conditions. The main focus was reliable detection of bright and dark conditions and stable automatic switching.

### Test Cases

1. Expose LDR to bright light → LED should remain OFF.
2. Reduce the surrounding light → observe sensor readings.
3. Cover the LDR or place it in darkness → LED should turn ON.
4. Repeat bright/dark tests → verify automatic response.

### Performance Considerations

Sensor readings may vary with the surrounding environment. Therefore, the threshold value should be calibrated during testing.

## 7. My Learnings

The project improved practical knowledge of:

- Embedded systems.
- Arduino microcontrollers.
- LDR sensor interfacing.
- Analog sensor reading.
- Conditional programming.
- Threshold-based control.
- Circuit troubleshooting.
- Testing and documentation.

## 8. Future Work Scope

Future improvements can include:

- Automatic brightness adjustment using PWM.
- PIR-based motion detection.
- Solar power integration.
- IoT-based monitoring.
- Multiple-light control.
- Remote status monitoring.
- Improved calibration and fault detection.
